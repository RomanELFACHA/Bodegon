<?php
require("db.php");
date_default_timezone_set("America/Argentina/Buenos_Aires");
$dni = $_POST['dniPrestado'];
$nombreApellido = $_POST['nomyapePrestado'];
$curso = $_POST['cursoPrestado'];
$grupo = $_POST['grupo'];
$idHerramientas = json_decode($_POST['idHerramientas']);
$numbTotalHerramientas = json_decode($_POST['numbHerramientras']);
$fecha = date('Y-m-d');
echo $fecha;

$inserted = true; // A flag to indicate if the insertion into "retiros" should occur

foreach ($idHerramientas as $pos => $value) {
    $sql3 = "SELECT `cant` FROM `herramientas` WHERE `id_h` = $value";
    $sqlEX3 = mysqli_query($connection, $sql3);
    $row = mysqli_fetch_array($sqlEX3);
    $cantidad = $row['cant'];
    $newCantidad = $cantidad - $numbTotalHerramientas[$pos];

    if ($newCantidad < 0) {
        // If the new quantity is negative for any tool, set the inserted flag to false
        $inserted = false;
        break; // Exit the loop
    }
}

if ($inserted) {
    $sql = "INSERT INTO `retiros`(`id_r`, `dni`, `nom_ape`, `grupo`, `curso`, `estado`, `fecha_ret`, `fecha_dev`) VALUES ('','".$dni."','".$nombreApellido."','".$grupo."','".$curso."','1','".$fecha."','')";
    $sqlEX = mysqli_query($connection, $sql);

    if ($sqlEX) {
        $ult_id = mysqli_insert_id($connection);

        foreach ($idHerramientas as $pos => $value) {
            $cantidad = $row['cant'];
            $newCantidad = $cantidad - $numbTotalHerramientas[$pos];

            if ($newCantidad == 0) {
                $sql6 = "UPDATE `herramientas` SET `cant`=$newCantidad ,`estado`='0' WHERE `id_h` = $value";
                $sqlEX6 = mysqli_query($connection, $sql6);

                if ($sqlEX6) {
                    $sql2 = "INSERT INTO `rel_rehe`(`id`, `id_retiros`, `id_herramientas`, `cantidad`) VALUES ('','".$ult_id."','".$value."','".$numbTotalHerramientas[$pos]."')";
                    $sqlEX2 = mysqli_query($connection, $sql2);
                }
            } else {
                $sql4 = "UPDATE `herramientas` SET `cant`=$newCantidad WHERE `id_h` = $value";
                $sqlEX4 = mysqli_query($connection, $sql4);

                if ($sqlEX4) {
                    $sql2 = "INSERT INTO `rel_rehe`(`id`, `id_retiros`, `id_herramientas`, `cantidad`) VALUES ('','".$ult_id."','".$value."','".$numbTotalHerramientas[$pos]."')";
                    $sqlEX2 = mysqli_query($connection, $sql2);
                }
            }
        }
        echo "Envío actualizado!";
    }
}
?>

<script>

    
</script>

