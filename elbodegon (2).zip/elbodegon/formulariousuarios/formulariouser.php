<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulario</title>
    <link rel="stylesheet" href="formulariouser.css">
</head>
<body>
    <h2>Formulario de Registro</h2>
    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
        <label for="dni">DNI:</label>
        <input type="text" id="dni" name="dni" required><br><br>

        <label for="contrasena">Contraseña:</label>
        <input type="password" id="contrasena" name="contrasena" required><br><br>

        <label for="nombre">Nombre y apellido:</label>
        <input type="text" id="nombre" name="nombre" required><br><br>

        <input type="submit" value="Enviar">
    </form>

  

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $servername = "127.0.0.1:3307";
        $username = "root";
        $password = "";
        $dbname = "pozo";

        $conn = new mysqli($servername, $username, $password, $dbname);
        if ($conn->connect_error) {
            die("La conexión falló: " . $conn->connect_error);
        }

        $dni = mysqli_real_escape_string($conn, $_POST['dni']);
        $contrasena = mysqli_real_escape_string($conn, $_POST['contrasena']);
        $nombre = mysqli_real_escape_string($conn, $_POST['nombre']);

        // Validación básica
        if (empty($dni) || empty($contrasena) || empty($nombre)) {
            echo "Por favor complete todos los campos.";
        } 
        
        else {

            $sql = "INSERT INTO `users`(`dni`, `password`, `nom_ape`) VALUES ('$dni', '$contrasena', '$nombre')";
            if ($conn->query($sql) === TRUE) {
                ?>
                <script>
                  alert ("se cargo correctamente")
                </script>
              <?php
            } else {

                ?>
                  <script>
                    alert ("Error al insertar datos en la base de datos: " . $conn->error;)
                  </script>
                <?php
               
            }
        }

        $conn->close();
    }
    ?>
</body>
</html>
