document.addEventListener('DOMContentLoaded', function () {
    const form = document.getElementById('registrationForm');

    form.addEventListener('submit', function (event) {
        event.preventDefault();

        const dni = document.getElementById('dni').value;
        const contrasena = document.getElementById('contrasena').value;
        const nombre = document.getElementById('nombre').value;

        if (dni.trim() === '' || contrasena.trim() === '' || nombre.trim() === '') {
            alert('Por favor complete todos los campos.');
        } else {
            fetch(form.action, {
                method: 'POST',
                body: new FormData(form)
            })
            .then(response => {
                if (response.ok) {
                    alert('Los datos se han cargado correctamente en la base de datos.');
                    form.reset(); // Limpiar el formulario después de enviar con éxito
                } else {
                    alert('Error al insertar datos en la base de datos.');
                }
            })
            .catch(error => {
                alert('Error de conexión al enviar el formulario.');
                console.error('Error:', error);
            });
        }
    });
});
