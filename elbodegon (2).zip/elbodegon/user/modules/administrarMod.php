<?php

include("../../connection.php");
$producto = $_POST['producto'];
$cantidad = $_POST['cantidad'];
$categoria = $_POST['categoria'];
$descripcion = $_POST['descripcion'];
$image = $_FILES['imagen'];
$blob = addslashes(file_get_contents($image["tmp_name"]));

   // Verificar si el archivo ya existe en la base de datos
   $queryCheck = "SELECT COUNT(*) AS count FROM herramientas WHERE nombre = '$producto'";
   $resultCheck = mysqli_query($connection, $queryCheck);

   if ($resultCheck) {
       $rowCheck = mysqli_fetch_assoc($resultCheck);
       $count = $rowCheck['count'];

       if ($count > 0) {
           // El archivo ya existe en la base de datos
           echo("El archivo '$producto' ya existe en la base de datos. No se puede agregar nuevamente. ");
        //    exit();
       } else {
         //falta implementar las categorias...?
         $sql = "INSERT INTO `herramientas`(`nombre`, `cant`,`estado`,`img`, `fk_cat`, `descripcion`) VALUES ('".$producto."','".$cantidad."',1,'".$blob."', '".$categoria."', '".$descripcion."')";
         $sqlEX = mysqli_query($connection, $sql);
         echo("Se cargó");
       }
   } else {
       echo "Error al verificar la existencia del archivo en la base de datos: " . mysqli_error($connection);
   }

?>