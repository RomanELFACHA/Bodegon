<?php
include("../../connection.php");
$query="SELECT * FROM categorias WHERE 1";
$result= mysqli_query($connection, $query);
 if ($result > 0){
  while ($row = mysqli_fetch_assoc($result)){
 echo "<option value='".$row['id_cat']."'>'".$row['nombre']."'</option>";
}
}
                        
 ?>