
<br><br><br><br><br><br><footer class="py-5 bg-black">
    <div class="container">
        <p class="m-0 text-center text-white small">Prestado de herramientas "El Bodegón" - 7°C Grupo 710 &copy; 2022</p> 
    </div>
</footer>
