<nav class="navbar navbar-expand-lg navbar-light bg-dark">
    <div class="container-lg">
        <a class="navbar-brand text-white" href="index.php">El Bodegón</a>
    </div>
</nav>