<?php
$connection = mysqli_connect(
  '127.0.0.1:3307', 'root', '', 'pozo'
);

?>